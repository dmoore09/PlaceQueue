#include "Place.h"

bool Place_Set(Place* const pPlace, uint32_t FID, char* Name, char* Lat, char* Long){

		pPlace->FID = FID;
		pPlace->Name = *Name;
		pPlace->Latitude = *Lat;
		pPlace->Longitude = *Long;
		return true;
	
	
	
		//return false;
	
}

bool  Place_Equals(const Place* const pLeft, const Place* const pRight){
	int rName = sizeof(pRight->Name) / sizeof(char); 
	int lName = sizeof(pLeft->Name) / sizeof(char);
	int rLat = sizeof(pRight->Latitude) / sizeof(char);
	int lLat = sizeof(pLeft->Latitude) / sizeof(char);
	int rLon = sizeof(pRight->Longitude) / sizeof(char);
	int lLon = sizeof(pLeft->Longitude) / sizeof(char);

	if (pLeft->FID == pRight->FID && rName == lName && rLat == lLat && rLon == lLon){
		for (int i = 0; i < rName; i++)
		{
			if (pRight->Name[i] != pLeft->Name[i])
			{
				return false;
			}
		}
		for (int j = 0; j < rLat; j++)
		{
			if (pRight->Latitude[j] != pLeft->Latitude[j])
			{
				return false;		
			}
		}
		for (int k = 0; k < rLon; k++)
		{
			if (pRight->Longitude[k] != pLeft->Longitude[k])
			{
				return false;
			}
		}
		
		return true;
	}
	return false;

}
